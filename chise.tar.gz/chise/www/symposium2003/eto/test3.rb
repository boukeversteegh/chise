#!/usr/bin/env ruby
$LOAD_PATH << '../ruby/src'
require 'chise'
include CHISE
"木".mydepth = 10
"林".mydepth = 20
"森".mydepth = 30
