#!/usr/bin/env ruby
$LOAD_PATH << '../ruby/src'
require 'chise'
include CHISE
p "木".mydepth
p "林".mydepth
p "森".mydepth
