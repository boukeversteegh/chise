//sysdep.h
//

#include <stdio.h>
#include <stdlib.h>

#include <math.h>

#include <sys/fcntl.h>

#include <png.h>

#include <db.h>

#include "kagestr.h"
