#ifndef YYSTYPE
#define YYSTYPE int
#endif
#define	STRING	257
#define	SETUP_TIMESTAMP	258
#define	SETUP_VERSION	259
#define	VERSION	260
#define	INSTALL	261
#define	SOURCE	262
#define	SDESC	263
#define	LDESC	264
#define	TYPE	265
#define	T_PREV	266
#define	T_CURR	267
#define	T_TEST	268
#define	T_UNKNOWN	269


extern YYSTYPE yylval;
