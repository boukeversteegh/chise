#!/bin/sh
emacs_is_beta=
emacs_major_version=21
emacs_minor_version=4
emacs_beta_version=22
xemacs_codename="Instant Classic"
emacs_kit_version=
infodock_major_version=4
infodock_minor_version=0
infodock_build_version=8
