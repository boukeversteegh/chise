#Configuration variables

#where the source is:

source = r"X:\XEmacs-21"
#where the installed distribution is:
installed = r"C:\Program Files\XEmacs\xemacs-21.0-b62"

#where the (built and installed) packages are
packages = r"C:\Program Files\XEmacs\xemacs-packages"

#where the package source is
pkg_src = r"X:\xemacs-packages"

#Subdirs relative to the base installation directory
#Everything except packages goes here:
dst = "XEmacs-21.0-b62"
#packages go here:
pkg_dst = "xemacs-packages"


