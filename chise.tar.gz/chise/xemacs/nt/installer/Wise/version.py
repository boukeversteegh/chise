title="XEmacs 21.0b62 EXPERIMENTAL"
welcome="Welcome to the %APPTITLE% setup program.  Please note that this is an experimental release and some features may not work correctly, especially on machines running Windows 95.  Please read the file PROBLEMS in the xemacs installation directory.  Send comments or bug reports to xemacs-nt@xemacs.org.  For more info see http://www.xemacs.org"

