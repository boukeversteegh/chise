#ifndef CONFIG_H
#define CONFIG_H
#define CHISE_DB_DIR    "/cygdrive/c/chise/chise-db"
#define CHISE_SI_DB_DIR "/cygdrive/c/chise/chise-db"
#endif
