# Copyright (C) 2002-2004 Kouichirou Eto, All rights reserved.

require "chise/character"
require "chise/string"
