module CHISE
  class Config
    VERSION = "0.2.1"
    RELEASE_DATE = "20040612"
  end
end
